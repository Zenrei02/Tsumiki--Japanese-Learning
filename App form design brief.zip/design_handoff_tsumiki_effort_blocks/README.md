# Handoff: tsumiki effort blocks

## Overview

The **effort block** is the visual unit representing one piece of work a learner did in
tsumiki, a Japanese-learning app for adult English speakers. Blocks accumulate into a stack
that is never finished and never shrinks. This handoff specifies the block object, its two
densities, the section-mark system, the stack at 100 and 1,000 blocks, the day-one empty
state, and the mobile **Progress** screen the stack lives in.

The product thesis is *growth and progress, not completion and perfection*: no lesson counts,
no percentage complete, no finish line. Every rule below follows from that. The full original
brief is bundled as `tsumiki-block-system-brief.md` — read it before implementing, as several
rules are non-negotiable product decisions rather than styling preferences.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing
intended look and behaviour, not production code to copy directly. The task is to **recreate
these designs in the target codebase's existing environment** (React, Vue, SwiftUI, Compose,
native, etc.) using its established patterns, component library, and token system. If no
environment exists yet, choose the framework appropriate to the project and implement there.

`Tsumiki Block System.dc.html` is a single-file streaming prototype and depends on a runtime
that is *not* part of the deliverable. Read it for values and structure; don't port its
scaffolding. The block-rendering algorithm in its logic class is the one part worth porting
closely — it is specified in prose below so you don't have to.

## Fidelity

**High fidelity.** Colours, type, spacing, radii, sizes and the per-block variation algorithm
are final and should be reproduced exactly. The one deliberate exception is the surrounding
page chrome of the spec sheet itself (headings, hairlines, margin notes) — that is
documentation, not product UI, and should not be built.

Two things are explicitly **unresolved** and must not be treated as final:

1. **The checker's mark.** 文 is a placeholder. Implement it as shipped, but keep the mark for
   each section in one data table so a single change swaps it.
2. **What one block represents.** Undecided. The checker is capped at three blocks per day;
   caps for other sections are not set. Block size may eventually vary with the amount
   written. Keep block size a parameter of the render function, not a constant.

---

## Hard rules (implementation constraints)

These are settled product decisions. Each exists because the obvious alternative reintroduces
a completion or punishment mechanic. Do not design around them or "improve" them.

| Rule | What it forbids in code |
| --- | --- |
| A block represents **effort only** | No block state derived from correctness, score, or the checker's three verdict tiers. A wrong answer earns the same block as a right one. |
| Nothing falls, decays, wilts, empties or greys out | No streak counter, no neglect/inactive state, no opacity or saturation tied to recency, no toppling or physics. Placed blocks are permanent and render at full tone forever. |
| No target silhouette | No goal outline, goal height, denominator, progress bar, or percentage anywhere in Progress. |
| No calendar grid, no day-rows | Blocks flow and wrap continuously in a single run. A row must never equal a day (a skipped day would become a visible hole — a streak with extra steps). Chronology is available on tap only. |
| Colour is never the sole carrier of meaning | Every section is identified by its character mark; the colour is secondary reinforcement. Never encode a section by tinting the block body. |
| Blocks outlive their source text | A block persists as `{ timestamp, moduleTag }`. Stored sentences are capped and evict over time; the block count must never decrease as a result. |

## Register

Cute but not infantile — warm, approachable, made. The failure mode to avoid is nursery.
Reference register: Muji, Japanese wooden toys made for adults. Not Duolingo, not Forest, not
habit-tracker garden apps.

- **Material, not plastic.** Warm wood tones with faint grain; never saturated primaries.
- **Small corner radius** — ~3px at a 26px block, scaled with size. Chunky rounding reads as toy.
- **Slight per-block variation** in grain and tone. No two blocks identical.
- **Restrained lowercase type.** No rounded friendly typefaces.

---

## The block object

### Geometry

A block is a square. Everything scales from its height `S`:

| Value | Formula | At S = 26px |
| --- | --- | --- |
| Width / height | `S` | 26px |
| Corner radius | `max(2, S × 0.115)` | 3px |
| Mark font size | `S × 0.54` | 14.0px |

**Size floor: 20px.** Below this the mark stops reading. Blocks never shrink past 20px; the
stack scrolls instead. (The alternative — falling back to a colour notch with marks returning
on zoom — was considered and rejected.)

Sizes used in the design: 20 (dense stack floor), 26 (default / 100-block stack), 30
(labelled rows and tapped block), 34, 48, 64 (vocabulary display only).

### Material

Each block is a stack of two CSS layers over one base tone. Base tone `T` = `#c8a877`.

Given a stable integer/float `seed` per block:

```
rand(n)  = fract(sin(n × 12.9898) × 43758.5453)      // deterministic 0..1
tone     = (rand(seed) − 0.5) × 26                    // ±13 RGB points
grainAmt = 0.5 + rand(seed + 7) × 0.5                 // 0.5..1.0
angle    = 84 + round(rand(seed + 3) × 12)            // 84..96 deg
step     = 2 + round(rand(seed + 11) × 3)             // 2..5 px grain pitch
```

```css
background:
  repeating-linear-gradient(<angle>deg,
    rgba(96,62,26, calc(0.09 * grainAmt)) 0 1px,
    rgba(255,255,255,0) 1px <step>px),
  linear-gradient(158deg, shift(T, tone + 10), shift(T, tone − 16));

box-shadow:
  inset 0  1px 0 rgba(255,252,244,0.42),   /* lit top edge */
  inset 0 -1px 0 rgba(88, 56, 22,0.20),    /* shadowed bottom edge */
  0 1px 1px rgba(60,40,18,0.10);           /* contact shadow */
```

`shift(T, d)` adds `d` to each RGB channel of `T`, clamped 0–255.

The seed must be **stable per block** (derive it from the block's id or timestamp), so a block
looks the same on every render and after reload. The grain pitch is 2–5px, so at the 20px floor
each block still shows 4–10 grain lines — do not scale the pitch with size.

Alternative wood tones tested and acceptable: `#d3b98f`, `#b8946a`, `#ddc9a6`. Grain strength is
a single multiplier on the `0.09` alpha; 1.0 is shipping value.

### Section marks

The block is always the same wood — **effort is the constant substance**. The section is
carried by a mark drawn in the section colour, centred in the block. Never tint the block body
by section: that makes effort from different sections into different materials, and at scale a
tinted stack reads as a stacked bar chart rather than an accumulation.

| Mark | Section | Colour | Notes |
| --- | --- | --- | --- |
| あ | Hiragana | `#55447c` | Purple pair — same skill, first script |
| ア | Katakana | `#63528f` | Purple pair, kept close; あ / ア does the separating |
| 漢 | Kanji | `#4e6a45` | Distinct hue, same value as the pair |
| 語 | Vocabulary | `#8f4a2c` | Warm, but never the wood tone itself |
| 文 | Checker | `#35606c` | **Placeholder mark** — see Unresolved, above |

Marks are set in **Noto Serif JP, weight 500**, `line-height: 1`, colour as above. A serif
Japanese face is required; a rounded or gothic face pushes the register toward kids' app.

The two purples are deliberately close in both hue and value: pushing katakana dark enough to
separate it by colour took it nearly to black, which defeats the point of a colour. The
character form carries the distinction. Both sit in the 3.5–4.5:1 band against the wood, so
neither reads as the faint one at the 20px floor. **Do not spread them apart.**

Each mark always pairs with an English name in the labelled density: あ Hiragana, ア Katakana,
漢 Kanji, 語 Vocabulary, 文 Checker. The English is not decoration — a beginner cannot read 漢
yet, and unfamiliar form beside known gloss is the app's own teaching pattern.

---

## Screens / views

### 1. Block — labelled density

**Purpose.** Legends, recent activity, and any tapped block. Anywhere with room.

**Layout.** Horizontal flex row, `gap: 12px`, `align-items: center`.
- 30px block (radius 4px, mark 16.2px)
- Text column, `line-height: 1.3`:
  - Section name — 14.5px, `--color-text`
  - Secondary line — 11.5px, text at 55% opacity, tabular numerals. Carries the module
    subtitle in a legend ("Recognition drill", "Readings and forms", "Words in context",
    "Sentence checked") or the timestamp when the row is a tapped block
    ("this morning", "yesterday, 21:40", "3 Sep, 19:05").

### 2. Block — bare density

**Purpose.** The stack itself, where hundreds of blocks appear and an English label would turn
a pile into a list.

**Layout.** Mark alone, centred. No label, no tooltip on hover.

### 3. Density transition

Tapping a bare block **promotes it in place**: the block keeps its position in the stack and a
labelled row appears immediately below the stack container showing that block's mark, section
name and timestamp. This is the only place chronology is exposed.

- Cursor `pointer` on tappable blocks only.
- Before any tap, the row shows italic hint copy at 48–50% text opacity:
  "Tap a block for when and where it came from."
- Reserve the row's height (`min-height: 46px` mobile, `54px` desktop) so promoting a block
  does not shift the stack.
- Selection is single; tapping another block replaces it.

### 4. The stack

**Purpose.** The accumulated record of everything the learner has done.

**Layout.** A wrapping flex container. Blocks flow and wrap continuously, newest last.

| Count | Block size | Gap | Container |
| --- | --- | --- | --- |
| ~100 | 26px | 4px | `align-content: flex-end` (pile settles to the bottom), `min-height: 240px`, 18px padding |
| 1,000+ | 20px | 3px | `align-content: flex-start`, fixed height, `overflow-y: auto` |

Container is a bordered, unfilled surface: `1px solid var(--color-divider)`, `border-radius: 4px`.

The pile gets **taller, never denser**, and never gains a top edge to reach. Do not add a
maximum height that the stack visibly fills, do not add a "keep going" caption tied to count,
and do not virtualise in a way that reveals a scrollbar thumb sized like a completion bar
(a plain scrollbar is fine).

At real scale, render performance matters: 1,000+ absolutely-positioned DOM nodes each with two
gradient layers and three shadows is the expensive path. Prefer either (a) precomputing each
block's style once and memoising the node by seed, or (b) drawing the dense view to a single
canvas / sprite sheet with the marks composited on top. Behaviour must be identical either way,
including tap-to-label hit testing.

### 5. Empty state — day one

**Purpose.** Zero blocks, and the same surface after a long absence.

**Layout.** Centred column on `var(--color-surface)`, bordered, `border-radius: 4px`,
`padding: 40px 28px`, `gap: 22px`, `text-align: center`.
- Heading — "Nothing here yet", Cormorant Garamond 23px
- Body — 14px, text at 72% opacity, `max-width: 30ch`:
  "Your first block is placed by your first piece of work. Any section counts, and nothing you
  do can take one away."
- A row of five outlined buttons, one per section, each showing only its character in the
  section colour (Noto Serif JP 15px, `padding: 8px 14px`) — the way in. Each navigates to its
  section.

**No ghost blocks, no outline of a finished shape, no height to reach.** There is no
denominator anywhere in the system, so day one cannot show one.

### 6. Progress (mobile, 390px)

**Purpose.** Progress is its own destination in the app — not a tab inside an account dialog.
An account is not a place; progress is one. The stack is the centrepiece.

**Layout,** top to bottom:

1. **App bar** — `tsumiki` (Cormorant Garamond 15px) left, つみき (12px, 55% opacity) right,
   `padding: 16px 20px 12px`.
2. **Title block** — "Progress", Cormorant Garamond 27px, weight 400. Below it, a baseline row
   `gap: 8px`: the count in Cormorant Garamond 22px tabular ("1,247") and the label "blocks
   placed" at 13px / 62% opacity. The count is a plain total, never `x of y`.
3. **The stack** — bordered scroll container, height 258px, 12px padding, 20px blocks, 3px gap,
   `align-content: flex-start`. Tappable.
4. **Selected-block row** — the labelled promotion described above, `min-height: 46px`.
5. **Hairline** — `1px solid var(--color-divider)`, full content width.
6. **Trend line** — the planned "errors per check, down since May" chart. Heading row: label in
   Cormorant Garamond 15px left, "down since May" at 11.5px tabular / 58% opacity right. Chart
   is an SVG polyline in **ink** (`var(--color-text)` at 70% opacity, 1.25px), a baseline rule
   in `var(--color-divider)`, and a single 2.6px gold dot (`var(--color-accent)`) on the latest
   point. 62px tall, full width.
7. **Tab bar** — top hairline, `padding: 12px 24px 16px`, four labels at 11.5px / 0.04em
   (Learn · Check · Progress · Account), space-between. Active item is `--color-accent-800`
   with a 1px accent bottom border.

**The stack and the trend must not visually contaminate each other.** The stack is *what you
did*; the trend is *what changed*, and the trend does carry performance. They are parted by a
hairline, and the trend uses no wood, no blocks and no section colours. Never draw the trend
over, behind, or inside the stack container, and never colour a block by trend direction.

---

## Interactions & behaviour

- **Tap a block** → that block is selected; the labelled row below the stack shows its mark,
  section and timestamp. Single selection; tapping another replaces it. No modal, no navigation.
- **Tap a mark in the empty state** → navigate to that section.
- **New block placed** → it appends to the end of the flow. If animated, animate the arrival
  only (a short settle of the new block, ≤200ms, ease-out). Never animate the whole stack,
  never animate blocks leaving, and never re-sort.
- **Hover** (desktop, if Progress ships there) → `cursor: pointer` on tappable blocks; no tone
  or scale change, which would read as state.
- **Scroll** → the dense stack scrolls vertically inside its container. No parallax, no
  sticky top edge.
- **Focus** → 2px `var(--color-accent)` outline, `outline-offset: 2px`. Blocks are focusable
  and operable by keyboard in the same order they appear.
- **Loading** → show the container with no blocks and no skeleton silhouettes; a skeleton grid
  would read as blocks the learner is missing. A quiet inline spinner or nothing is correct.
- **Error / offline** → show the last known stack and count. Never show zero on failure: an
  apparently shrinking stack is the one thing the system must never do.

### Accessibility

- Each block: `role="button"`, accessible name of the form "Hiragana block, this morning".
- The count is announced as a plain total, not a ratio.
- The mark colours sit at 3.5–4.5:1 on the wood; they are reinforcement only, and the character
  plus the accessible name carry the meaning. Verify any retune of the wood tone against both
  purples.
- Respect `prefers-reduced-motion` by dropping the arrival animation entirely.

## State management

| State | Type | Notes |
| --- | --- | --- |
| `blocks` | `Array<{ id, timestamp, moduleTag }>` | Append-only. Never filtered, never pruned, never reordered. Source of truth for the count. |
| `count` | derived | `blocks.length`. Persist independently as a monotonic counter if blocks are ever paginated server-side — the displayed total must never fall. |
| `selectedBlockId` | `string \| null` | Drives the labelled promotion row. Resets on leaving Progress. |
| `trend` | `Array<{ period, errorsPerCheck }>` | Fetched separately from blocks. A trend failure must not blank the stack. |

Blocks are stored as a timestamp plus a module tag only, so they survive the eviction of the
sentences that produced them. Per-block visual variation is derived from `id`, not stored.

Caps: the checker is capped at three blocks per day. Caps for other sections are not yet set —
put the cap in configuration, not in the render path.

## Design tokens

From the **Classical** design system (`styles.css`, bundled). Use the codebase's equivalents
where they exist; take the raw values below only where they don't.

**Colours**

| Token | Value | Use |
| --- | --- | --- |
| `--color-bg` | `#f3f2f2` | Page and screen ground |
| `--color-surface` | `#eae9e9` | Empty-state panel |
| `--color-text` | `#201f1d` | Ink; trend line at 70% |
| `--color-accent` | `#b68235` | Rules, active tab underline, latest trend point |
| `--color-accent-800` | ramp step | Active tab label, links |
| `--color-divider` | `#201f1d` at 16% | Every hairline and container border |
| Wood base | `#c8a877` | Block body (varied ±13 per channel) |
| Grain | `rgba(96,62,26,0.09)` | Grain lines, ×0.5–1.0 per block |
| Block edges | `rgba(255,252,244,0.42)` / `rgba(88,56,22,0.20)` | Inset top / bottom |
| Contact shadow | `rgba(60,40,18,0.10)` | `0 1px 1px` |
| Section colours | see Section marks | Marks only — never fills |

Text opacities used as a scale: 48% (hint), 55% (secondary), 62% (caption), 72% (body
secondary), 78% (lede).

**Spacing.** Classical's scale: 9.2 / 13.8 / 18.4 / 27.6 / 36.8px. Block gaps are the one
exception — 3px at 20px blocks, 4px at 26px — because they are material spacing, not layout.

**Type**

| Role | Family | Size / weight |
| --- | --- | --- |
| Screen title | Cormorant Garamond | 27px / 400 |
| Count | Cormorant Garamond | 22px / 400, tabular |
| Section heading | Cormorant Garamond | 15–19px / 400 |
| Body | Lora | 15px / 400, line-height 1.62 |
| Secondary | Lora | 11.5–13.5px |
| Kicker / tab label | Lora | 11–11.5px, 0.04–0.12em, uppercase for kickers |
| Block mark | Noto Serif JP | `S × 0.54` / 500 |

Bold is avoided throughout; italics and size carry emphasis. All figures standing as numbers
are tabular (`font-variant-numeric: tabular-nums`); running prose keeps text figures.

**Radius.** 2 / 4 / 7px from the token scale; blocks use `max(2, S × 0.115)`; the phone frame
in the mock uses 22px (device chrome only, not a product value).

**Shadows.** `--shadow-sm/md/lg` from the token sheet — elevation here is a whisper. The block's
own three-layer shadow is material, not elevation; don't substitute a token for it.

## Assets

- **Fonts.** Cormorant Garamond and Lora (Google Fonts, loaded by Classical's `styles.css`);
  **Noto Serif JP** weights 400/500 (Google Fonts) for the marks — a required addition, since
  neither Latin face covers kana or kanji.
- **Icons.** Lucide, per the design system. None used in these screens.
- **Images.** None. The blocks are drawn entirely in CSS; there are no bitmap wood textures to
  ship.

## Files

| File | What it is |
| --- | --- |
| `Tsumiki Block System.dc.html` | The design reference: all six deliverables on one scrolling spec sheet, with the live block renderer and tap-to-label interaction. Open in a browser. |
| `tsumiki-block-system-brief.md` | The original product brief. Authoritative on the hard rules, register and open questions. |
| `styles.css` | The Classical design system's token sheet and component layer, as linked by the prototype. |
